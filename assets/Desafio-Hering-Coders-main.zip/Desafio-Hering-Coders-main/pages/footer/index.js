import './style.css'

function Footer() {
  return `
  <div class="footer">
    <div class="container">
      <div class="title">
        Desenvolvidis por <a href="https://www.linkedin.com/in/alison-rocha-77672b105/"> Alison Rocha </a>
      </div>
    </div>
  </div>  
  `
}

export default Footer
