//Salvar no localStorage e

const form = document.getElementById('form')

form.addEventListener('submit', function (e) {
  const $name = document.getElementById('name').value
  const $email = document.getElementById('email').value

  localStorage.setItem('name', $name)
  localStorage.setItem('email', $email)

  window.location.reload()

  e.preventDefault()
})

//fechar menu
const closeMenu = document.getElementById('closeMenu')

closeMenu.addEventListener('click', function (e) {
  document.getElementById('menu').style.display = 'none'
  document.getElementById('closeMenu').style.display = 'none'
  document.getElementById('open').style.display = 'block'
})

//Fechar Modal
const closeModal = document.getElementById('closeModal')

if (closeModal != null) {
  closeModal.addEventListener('click', function (e) {
    document.getElementById('ismodal').hidden = true
    e.preventDefault()
  })
}

//Abrir
const open = document.getElementById('open')

open.addEventListener('click', function (e) {
  document.getElementById('open').style.display = 'none'
  document.getElementById('closeMenu').style.display = 'block'
  document.getElementById('menu').style.display = 'block'

  e.preventDefault()
})
